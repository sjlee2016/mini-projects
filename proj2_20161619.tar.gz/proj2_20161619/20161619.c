#include <stdio.h>
#include <string.h>
#include <stdlib.h>
typedef struct BANK * bptr;
typedef struct USER * uptr;
typedef struct ACCOUNT* aptr;
typedef struct NODE* hptr;
typedef struct _node // 거래 내역을 담을 구조체
{	
	int num;
	int act;
	double current_amount;
	
	struct _node* next;
}NODE;
typedef struct _listHistory //거래 내역을 담을 구조체 STACK 머리 
{
	NODE* head;
}HISTORY;
typedef struct ACCOUNT // 계좌 구조체
{
	char* account_name; //계좌 번호
	float amount;  //계좌 잔액
	HISTORY* history; //거래내역
	aptr head;
	aptr account_link;
}ACCOUNT;
typedef struct USER  // 고객 구조체 
{
	int num; // 이 고객이 가지고 있는 계좌의 수
	char* user_name; // 고객의 이름 
	ACCOUNT* account; // 고객의 계좌 리스트
	uptr user_link;  
	uptr head;
}USER;
typedef struct BANK // 은행 구조체
{
	bptr head;
	float bank_amount; // 은행의 순자산
	char* bank_name; // 은행의 이름
	USER *users;   // 은행의 고객 리스트 
	bptr bank_link;
}BANK;
void freeBank(BANK*);
void freeHistory(HISTORY*); // 이 4가지에 함수들은 프로그램이 끝나기전에 사용했던 메모리를 헤제해주기 위해 만든 함수이다.
void freeUser(USER*);       // freebank 안에서 freeUser를 부르고 freeUser 안에서 free Account를 그리고 그안에서 freeHistory를 
void freeAccount(ACCOUNT*); // 불러오는 방식으로 메모리를 헤제해주었다. 
void insert_User(USER* userList, char* name, char*, double); // 새로운 고객을 고객 리스트에 넣어주는 함수이다.
BANK* Initiate_Bank(USER*,USER*,USER*); // 처음 프로그램이 시작했을때 input.txt 에 있는 고객리스트를 각 은행에 넣어주고 은행을 초기화 해주는 함수.  
int select_Bank(BANK* BankList);//은행을 선택하는 함수
void selected_Bank(BANK*,int); // 선택한 은행의 이름을 출력하는 함수
int select_Menu2(BANK*,int); //  두번째 메뉴를 출력해주고 입력을 받는 함수
int selectMenu_first(BANK*); // 처음 은행 메뉴를 출력해주고 입력을 받는 함수
int search_User(USER*,char*); // 고객 리스트에 해당 이름을 가진 고객이 있는지 확인하는 함수
int select_Menu3(int,BANK*,int,char*); // 세번째 메뉴를 출력해주고 입력을 받는 함수
int print_User(int,BANK*,int); // 고객을 출력해주는 함수. 모드가 3가지가 있다. 뒤에서 설명하겠다.
void printline() // =를 24번 출력해주는 함수. 프로그램에 모양을 잡아준다 
{
	int n;
	for(n=0;n<24;n++)
	{
		printf("=");
	}
		printf("\n");
}
int searchAccount(BANK* bankList, char* accountNum) // 모든 은행 리스트에서 해당 계좌번호를  가진 계좌가 있는지 체크한다. 
{
	BANK* btemp;
	USER* utemp;
	ACCOUNT* atemp;
	for(btemp=bankList;btemp!=NULL;btemp=btemp->bank_link) // 은행리스트에서 각각 은행으로 옮겨가며 탐색한다 
	{
		for(utemp=btemp->users->user_link;utemp!=NULL;utemp=utemp->user_link) // 은행리스트의 고객리스트에서 각각 고객으로 옮겨가며 탐색한다
		{
			for(atemp=utemp->account->account_link;atemp!=NULL;atemp=atemp->account_link) // 고객의 계좌에서 다음 계좌로 옮겨가며 탐색한다 
			{
				if(strcmp(atemp->account_name,accountNum)==0) //만약 고객의 계좌의 계좌 번화와  accountNum 과 같다면 1 을 리턴한다
				{
					return 1;
				}
			}
		}
	}
	return 0; // 루프가 다 돌았고 이 지점으로 프로그램이 도달했다는것은 해당계좌번호가 어느 은행에도 없다는걸 뜻한다. 
	          //그러므로 0을 리턴한다. 
}
void insert_Account(USER* userList, ACCOUNT*,char*,double); // 계좌를 계좌 리스트에 넣어주는 함수 
void SPush(HISTORY* pHistory, int act, double amount) // HISTORY 라는 STACK 구조체에다가 새로운 NODE를 넣어주는 함수 
{
	NODE* newNode= (NODE*)malloc(sizeof(NODE)); //HISTORY 는 계좌 내역을 저장하는 STACK이다. 
	newNode->act=act;				// ACT는 1일때는 registered 2는 deposits and withdrawls 3은 loan 을 뜻한다. 
	newNode->current_amount=amount;			// 다른 함수에서 이 숫자를 이용해 나중에 고객이 계좌 내역을 출력하고 싶다면 출력해줄것이다.
	newNode->next=pHistory->head;			// NODE의 currentAmount는 그 당시에 계좌의 총 액수를 뜻한다. 
	pHistory->head=newNode;
	
}
	


BANK* Initiate_Bank (USER* bank1, USER* bank2, USER* bank3) // 처음 은행 리스트를 만들어주는 함수
{
	int n;							// 메인함수에서 이미 input.txt에 들어있는 고객들을 리스트에 넣어준후에 이 함수를 불러준다.
	double total;						// bank1 은 너네은행 bank2는 회사은행 bank3는 백성은행의 고객리스트이다. 
	char* name;						
	BANK* BankList;
	BankList=NULL;
	BANK* temp;
	name=(char*)malloc(sizeof(char)*100);
	for(n=0;n<3;n++)		//  루프를 통해 세 은행을 만들고 이를 linked list로 구현한다. 
	{	
		switch (n)
		{
			case 0: strcpy(name,"너네은행");  //각 n 에 따라 은행에 이름을 정한다. 곧, 처음 은행은 너네은행, 다음은 회사은행 그리고 마지막은 백성은행이
				break;			  //만들어진다.
			case 1: strcpy(name,"회사은행");
				break;
			case 2: strcpy(name,"백성은행");
				break;
		}
		BANK* newBank=(BANK*)malloc(sizeof(BANK));
		newBank->bank_name=(char*)malloc(sizeof(char)*100);
		strcpy(newBank->bank_name,name);
		newBank->bank_amount=100000;        // 은행의 순 자산은 처음에 모두 100,000원에 시작된다. 
		newBank->bank_link=NULL;
		switch(n)
		{
			case 0: newBank->users=bank1;   //각 은행에 따라서 알맞는 고객 리스트를 넣어준다. 
				break;
			case 1: newBank->users=bank2;
				break;
			case 2: newBank->users=bank3;
				break;
		}
		if(BankList==NULL)
		{	
			BankList=(BANK*)malloc(sizeof(BANK)); //루프 밖에서 bankList를 선언해줄때 처음에 NULL 이였기 때문에 n=0 일때, 즉 너네은행일때 이 조건이 
			BankList->head=newBank;		      // 만족되어 너네은행은 은행리스트의 head가 된다.
			BankList=newBank;		      // 이제 bankList는 니네은행이 되기때문에 다음에 루프를 돌때 다음 조건으로 넘어간다. 
		}else
		{  						
			for(temp=BankList;temp->bank_link!=NULL;) // 회사은행, 백성은행을 만들어줬을때 그 둘을 차례대로 연결한다. 
			{
				temp=temp->bank_link;		// 즉, 이제 이 은행리스트에는 니네은행->회사은행->백성은행이 차례대로 연결되있다. 
			}
			temp->bank_link=newBank;
		
		}
				

	}

	return BankList;
}
double total_bank(BANK* BankList) // 은행에 모든 고객들의 계좌의 액수의 총 값을 구한다 
{
	double total=0;
	USER* utemp;
	ACCOUNT* atemp;
	for(utemp=BankList->users->user_link;utemp!=NULL;utemp=utemp->user_link) // 이중 루프를 통해 은행의 모든 고객의 모든 계좌의 자산을 더한다 
	{
		for(atemp=utemp->account->account_link;atemp!=NULL;atemp=atemp->account_link)
		{
			total+=atemp->amount;
		}
	}
	return total;
}
int select_Bank(BANK* BankList) // 사용자가 은행을 고를수 있게 은행의 이름과 은행의 총 액수(순 자산 + 고객 자산) 를 display 하고 
{				// 어떤 은행을 고를것인지 입력을 받는다. 
	BANK* temp;
	int n,output;
	n=1;
	printf("===== SELECT BANK ======\n");
	for(temp=BankList;temp!=NULL;temp=temp->bank_link) // 루프를 통해 은행리스트에 있는 모든 은행의 이름과 총 액수를 프린트한다 
	{       	
		printf("%d. %s (total amount : %.6lf )\n",n,temp->bank_name,temp->bank_amount+total_bank(temp));
		n++;
	}	
	printline();
	printf("select menu : ");
	scanf("%d",&output);
	while(output<=0||output>3) // 사용자가 1~3만 고를수있게 다시 입력 받는다
	{
		printf("select from (1)~(3)!: ");
		scanf("%d",&output);
	}
	printline();
	return output;
}
void selected_Bank(BANK* BankList, int bankNum) // 사용자가 선택한 은행의 이름을 프린트한다. 
{	
	int num,n;
	n=1;                                                                                                                       
	BANK* temp;
	if(BankList->users!=NULL)
	{
	}else
	{	
		for(temp=BankList->bank_link;n<bankNum;n++) // bankNum 에 따라 은행리스트에서 은행을 찾는다. bankNum 이 1이면 너네은행 2면 회사은행 3이면 백성은행이다. 
		{
			temp=temp->bank_link;
		}
		printf("You choose %s\n", temp->bank_name); //은행의 이름을 프린트한다
		printline();
	}
	

}	
int select_Menu2(BANK* BankList,int bankNum) // 은행 메뉴2 (로그인 화면) 을 출력해주고 입력을 받는다
{	
	int n;
	printf("===== MENU ( BANK )=====\n");
	printf("1. select user \n");
	printf("2. new user registration \n");
	printf("3. go to menu \n");
	printf("------------------------\n");
	printf("select menu : ");
	scanf("%d",&n);	
	if(n<=0||n>3)
	{	
		printf("please select from (1)~(3)\n");  // 사용자가 1~3만 입력하도록 한다. 
		n=select_Menu2(BankList,bankNum);
	}
	printline();
	return n;
}
int selectMenu_first(BANK* BankList) // 처음 초기 메뉴를 프린트한다. 
{
	int d=0;
	
	printf("========= MENU =========\n");
        printf("1. select bank\n");
        printf("2. bank user and user account list\n");
        printf("3. quit\n");
        printline();
        printf("select menu : ");
	
	scanf("%d",&d);
	while(d<=0||d>3)
	{
		printf("please select from (1)~(3). \n");
		scanf("%d",&d);					//사용자가 1~3만 입력하도록 한다. 
	}
	printline();
	return d;	
}
int search_User(USER* userList,char* name) // 해당 고객리스트에서  name이라는 이름을 가진 고객이 있는지 확인하는 함수.  
{					   
	USER* temp;
	int found=0;
	for(temp=userList->user_link;temp!=NULL;temp=temp->user_link) //루프를 통해 고객리스트를 탐색한다
	{
		if(strcmp(temp->user_name,name)==0) // 고객의 이름과 name이 같다면 1를리턴한다 
		{
			found=1;
			return found;
		}
	}
	return found; // 찾지못하엿다면 0을 리턴한다 
}
int select_Menu3(int bank, BANK* BankList,int mode, char* cName) // 로그인 메뉴에서 새로운 고객을 만들거나 기존 고객을 선택할때 이용되는 함수
{
	int d,n,k;			// 여기서 이 함수는 모드가 1과 2가 존재한다. 1은 이 함수가 불러지기 전에 사용자가 1)  select user를 택했을때이고  
	BANK* temp;								//   2는 이 함수가 불러지기 전에 사용자가 2)  new user registration 을 택했을때이다
	char* name;
	name=(char*)malloc(sizeof(char)*100);
	USER* list;
	if(bank==1)   // bank 에 따라 올바른 은행에 접근한다. 1 일때 너네은행 2일때 회사은행 3일때 백성은행이다.
	{
		temp=BankList;	
	}else if(bank==2)
	{
		temp=BankList->bank_link;
	}else
		temp=BankList->bank_link->bank_link;
	

	list=temp->users;
	printf("type user's name : ");
	scanf("%s",name);  // 고객의 이름을 입력 받는다.
	if(mode==1)  // 1)select user 이였을때. 즉 해당 고객의 이름이 존재하는지 체크해야한다. 
	{
		if(search_User(list,name)==1)
		{
		  strcpy(cName,name); // 존재한다면 함수에 6을 output으로 해준다. 이를통해 함수밖에서는 6을 받고 USER 메뉴로 넘어갈것이다.
		  k=6;
		}else
		{
			printf("the username does not exists\n");	// 존재하지않는다면 오류를 출력해주고 전에 메뉴로 다시 돌아간다. 
			printline();
			k=4;
		}
	}else if (mode==2) // 2)new user registration 을 입력했을때. 즉 반대로 해당 고객의 이름이 존재를 한다면 오류를 출력해줘야 한다.
	{ 
		if(search_User(list,name)==1) // 존재하기 때문에 오류를 출력하고 전에 메뉴로 돌아간다. 
		{
			printf("the username already exists\n");
			printline();
			k=5;
		}else
		{
			strcpy(cName,name);  	// 존재를 하지않기 때문에 새로운 고객을 만들어 고객 리스트에 넣는다.
		        insert_User(temp->users,name,"NO ACCOUNT MADE",0); // 고객만 만들고 계좌를 만들지 않았기 때문에 초기 계좌이름은 NO ACCOUNT MADE 그리고 
			printline();					   // 잔액은 0으로 한다. 
			k=6; // USER 메뉴로 넘어간다.
		}
	}
	return k;
}
void insert_Account(USER* userList, ACCOUNT* accountList, char* accountNum, double num) //  새로운 계좌를 계좌 리스트에 넣어주는 함수.
{
	
	if(userList->num<=4) // 만약 고객이 5개 이상의 계좌를 만들었다면 더이상 만들지 못하게 한다. 
	{
		userList->num++;	//만들때마다 num 을 증가시켜 같은 고객이 얼마나 많은 계좌를 가지고 있는지 체크해준다.
		ACCOUNT* temp;
		ACCOUNT* newAccount=(ACCOUNT*)malloc(sizeof(ACCOUNT));
		newAccount->account_name=(char*)malloc(sizeof(char)*100);
		newAccount->amount=num;
		strcpy(newAccount->account_name,accountNum);	// 입력 받은 계좌 번호와 계좌액수를 새로운 계좌에 입력한다.
		newAccount->history=(HISTORY*)malloc(sizeof(HISTORY)); // 계좌의 계좌 내역을 만든다.
		newAccount->history->head=NULL; 
		SPush(newAccount->history,1,num);	//계좌내역에 처음 registered 했다는걸 표시하기 위해 push 해준다 
		newAccount->account_link=NULL;
			if(accountList==NULL) // 계좌리스트에 아무것도 없다면 이 계좌가 처음 계좌, 즉 head 가 된다 
			{
				accountList->head=newAccount;
				accountList=newAccount;
			}else
			{
				for(temp=accountList;temp->account_link!=NULL;) // 기존에 계좌리스트에 계좌가 들어있다면 계좌 리스트 끝을 찾는다
				{
					temp=temp->account_link;
				}
			temp->account_link=newAccount; //계좌 리스트 끝에 새로운 계좌를 연결한다. 
			}
	}else
	{
		printf("cannot add more account! \n"); //오류 출력
		printline();
	}
}

void insert_User(USER* userList, char* name, char* accountNum, double num) // 새로운 고객을 고객 리스트에 삽입하는 함수
{
	USER* newUser;
	USER* temp,temp2;
	newUser=(USER*)malloc(sizeof(USER));
	newUser->user_name=(char*)malloc(sizeof(char)*100);
	strcpy(newUser->user_name,name);
	newUser->user_link=NULL;
	newUser->num=0;
	newUser->account=(ACCOUNT*)malloc(sizeof(ACCOUNT));
	insert_Account(userList,newUser->account,accountNum,num); // 고객 계좌리스트에 계좌를 넣어준다 
	
	if(userList==NULL) // 고객 리스트에 아무것도 없었다면 새로운 고객이 처음 고객 리스트 head가 된다
	{
		userList->head=newUser;
		userList=newUser;
	}else
	{
		for(temp=userList;temp->user_link!=NULL;) // 고객 리스트에 이미 고객이 들어가 있다면 고객리스트에 끝을 찾아 새로운 고객을 연결한다 
		{
			temp=temp->user_link;
		}
		temp->user_link=newUser;
	}
}
void print_All(BANK* BankList) // 세 은행의 모든 고객의 이름, 고객의 계좌 번호, 고객의 계좌 잔액을 프린트 하는 함수. 단 은행에 이름은 프린트하지 않는다
{
	int n;
	printline();
	for(n=1;n<4;n++)
	{
		print_User(n,BankList,3);	// n 이 1일땐 너네은행 2일땐 회사은행 3일땐 백성은행의 고객을 프린트한다
	}
	printline();
}
int print_User(int num, BANK* BankList,int mode) // 총 모드가 3가지인 고객을 프린트해주는 함수
{
	BANK* btemp;				// 모드 1& 3: 은행에 모든 고객의 이름, 고객의 계좌, 계좌 잔액 출력  mode 2: 은행에 모든 고객의 이름만 출력
	if(num==1) // num 에 따라 접근해야하는 은행을 알아낸다.  1-3 일때 차례대로 니네,회사,백성 은행
	{
		btemp=BankList;
	}else if(num==2)
	{
		btemp=BankList->bank_link;
	}else
		btemp=BankList->bank_link->bank_link;
	
	ACCOUNT* atemp;
	USER* temp,*userList;
	userList=btemp->users; 
 	if(mode==1||mode==2) // 모드가 1,2일때만 은행의 이름을 출력한다. 
		printf("%s\n\n",btemp->bank_name);
	
	if(mode==1||mode==3) // 모드가 1이나 3일때
	{
	if(userList==NULL)
	{
		return 0;
	}
	for(temp=userList->user_link;temp!=NULL;temp=temp->user_link)  // 이중 루프를 통해 은행의 모든 고객의 모든 계좌 리스트를 탐색한다. 
	{
		for(atemp=temp->account->account_link;atemp!=NULL;atemp=atemp->account_link)
		{
		if(strcmp(atemp->account_name,"NO ACCOUNT MADE")==0&&atemp->account_link!=NULL)	 // 탐색중 NO ACCOUNT MADE 이름을 가졋는데 그 후에도 다른 계좌가 있을경우에는
		{										 // 출력하지 않는다

		}
		else if (atemp->account_name!='\0') // 계좌 이름이 NULL 이 아니라면 고객 이름, 계좌 번호, 계좌 액수를 프린트한다. 
		{	
		printf("%s\n%s\namount : %0.6lf\n", temp->user_name, atemp->account_name,atemp->amount);
		}
		}
	}
		if(mode==1) // 모드가 1일때는 끝에 은행의  총 액수까지 프린트한다. 
		{	
			printf("bankTotalAmount : %0.6lf\n",btemp->bank_amount+total_bank(btemp));
			printline();	
		}
	}else if(mode==2) // 모드가 2일때는 고객의 이름만 프린트한다. 
	{
		for(temp=userList->user_link;temp!=NULL;temp=temp->user_link)
		{
			printf("%s\n",temp->user_name);
		}
		printline();
	}
	
} 
void print_account_info(char* name, ACCOUNT* accountList) // 어떤 고객의 계좌 리스트에 있는 계좌의 계좌번호와 액수를 프린트한다.
{
	ACCOUNT* temp;
	char* copy;
	copy=(char*)malloc(sizeof(char)*100);
	strcpy(copy,name);
	if(accountList!=NULL)
	{
	
	
	for(temp=accountList->account_link;temp!=NULL;temp=temp->account_link)
	{
		if(strcmp(temp->account_name,"NO ACCOUNT MADE")==0&&temp->account_link!=NULL)
		{	
		}		//NO ACCOUNT MADE이고 다른 계좌가 리스트에 있다면  그 계좌가 빈 계좌, 즉 의미 없는 계좌이기 때문에 제외해준다. 
		else
		{
	        printf("%s\n",copy);
		printf("%s\namount : %0.6lf\n",temp->account_name,temp->amount); 
		}
	}
	printline();
	}
}
int search_Account_2(ACCOUNT* accountList, char* accountNum) // 계좌 리스트에서 accountNum 와 일치하는 계좌 번호를 가진 계좌가 있는지 찾는 함수
{
	ACCOUNT* temp;
	for(temp=accountList->account_link;temp!=NULL;temp=temp->account_link) // 루프를 통해 계좌 리스트를 탐색한다 
	{
		if(strcmp(temp->account_name,accountNum)==0) // 계좌 리스트에 있는 계좌중에 acccountNum과 같은 계좌 번호를 가진 계좌가 있다면
		{
			return 1; // 1를 리턴한다 
		}
	}
	return 0; // 찾을수 없다면 0 을 리턴한다 
}
int update(BANK* bankList, ACCOUNT* accountList, char* accountNum, double amount) // deposit & withdrawl 를 해주는 함수 
{										// 이 함수가 불러지기전에 accountNum 라는 계좌 번호가 해당 계좌 리스트에 있는걸 확인한 상태 이다. 
	ACCOUNT* temp; 
	for(temp=accountList->account_link;temp!=NULL;) // 계좌번호가 accountNum 인 계좌를 찾는다 
	{
		if(strcmp(temp->account_name,accountNum)==0) // 이 루프가 끝나면 temp 는 accountNum를 가진 계좌를 가르킨다 
		{
			break;
		}else
		{
			temp=temp->account_link;
		}
	}

	if((temp->amount)+amount<0) // 해당 계좌의 잔액보다 더 많이 출금하려하면 오류를 출력한다 
	{
		printf("There is not enough amount\n");
		printline();
		return -1;		
	}else
	{
		temp->amount=temp->amount+amount;  // 그렇지 않다면 해당 계좌에서 원하는 액수를 더하거나  뺀다. amount 가 - 이면 출금 amount 가 + 면 입금을 뜻한다.
		SPush(temp->history,2,temp->amount); // 계좌의 history 에 2 와 계좌의 잔액을 push 해줌으로써 계좌 내역을 저장한다 
		return 0;
	}
	
}
int loan(BANK* bankList, ACCOUNT* accountList, char* accountNum) //대출을 도와주는 함수이다. 이미 함수 밖에서 accountNum라는 계좌번호를 가진 계좌가  accountList에 
{								 // 있는걸 확인한 상태이다. 
	ACCOUNT * temp;
	double amount;
	for(temp=accountList->account_link;temp!=NULL;)  // 이 루프를 통해 temp 는 accountNum 와 동일한 계좌번호를 가진 계좌를 가르킨다. 
	{
		if(strcmp(temp->account_name,accountNum)==0)
		{
			break;
		}else
			temp=temp->account_link;
	}
	if(temp->amount<0)  // 만약 해당 계좌의 잔액이 0보다 작으면 대출을 금지하고 오류를 출력한다
	{
		printf("There is not enough amount to loan\n");
		printline();
		return -1;
	}
	printf("type amount : ");
	scanf("%lf",&amount);
	if(amount<0) // 만약 대출하려는 금액이 0보다 작다면 말이 되지 않으므로 오류를 출력한다 
	{
		printf("you cannot loan a negative number \n");
		printline();
		return -1;
	}
	if((bankList->bank_amount+total_bank(bankList))-amount<0) // 만약 은행의 총  자산보다 더 큰 액수를 대출하려하면 금지하고 오류를 출력한다 
	{
		printf("you can not loan beyond the limit of the loan\n");
		printline();
		return -1;
	}else  
	{					 // 위 컨디션에 모두 해당하지 않다면 대출 가능한 계좌와 액수라는걸 뜻한다 
		bankList->bank_amount-=amount;   // 그러므로 해당 계좌에 원하는 액수를 더하고 은행에 순 자산에서는 그 액수를 뺀다 
		temp->amount+=amount;
		SPush(temp->history,3,temp->amount); // 계좌의 historyh 에 3과 계좌의 액수를 push 하여 loan 을 했다는걸 계좌 내역에 기록한다. 
		return 0;
	}

}
int transfer(BANK* bankList, char* received, char* give, ACCOUNT* accountList, char* name) // 계좌 이채를 가능하게 해주는 함수이다
{
	double amount;									 // 이미 received 가 세 은행중에 존재하는 계좌 번호인걸 확인한 상태이다
	int flag;								         // give라는 계좌 번호  또한 accountList 계좌 리스트에 존재한다 
	flag=0;
	BANK* btemp;
	USER* utemp;
	char* rName;
	ACCOUNT* atemp, *atemp2, *re;
	printf("type the amount : ");
	scanf("%lf",&amount);
	printline();
	rName=(char*)malloc(sizeof(char)*100);
	for(btemp=bankList;btemp!=NULL;btemp=btemp->bank_link)  // 이 삼중 루프를 통해 received 라는 계좌 번호가 어디 있는지 찾는다
	{
		for(utemp=btemp->users->user_link;utemp!=NULL;utemp=utemp->user_link)
		{
			for(atemp=utemp->account->account_link;atemp!=NULL;atemp=atemp->account_link)
			{
				if(strcmp(atemp->account_name,received)==0) //이 루프를 나오게 되면 re 는 received 라는 계좌 번호를 가진 계좌를 가르키게 된다.
				{ 
					strcpy(rName,utemp->user_name); // 그 계좌의 주인의 이름을 찾고 다른 char 배열에 복사를 한다.
					re=atemp;
					break;
				}
			}
		}
	}
	for(atemp2=accountList->account_link;atemp2!=NULL;atemp2=atemp2->account_link) // 루프를 통해 give 라는 계좌 번호가 어디있는지 찾는다
	{
		if(strcmp(atemp2->account_name,give)==0) // 이 루프에 나오게 되면 atemp2 는 give라는 계좌 번호가 가진 계좌를 가르키게 된다. 
		{
			break;
		}	
	}
	if(amount<0||atemp2->amount<amount)  // 만약 계좌 이채를 하는데 마이너스 금액을 이채 할려고 하거나 이채를 하려는 계좌에 그 만큼에 금액이 없을때 오류를 출력한다
	{	
		printf("the amount is insufficient and can not be transferred \n");
		printline();
		return -1;
	}else
	{			
		printline();
		re->amount=re->amount+amount;		// 이채를 받을 계좌의 액수를 이채한 액수만큼 더한다
		atemp2->amount=atemp2->amount-amount;	// 이채를 한 계좌에선 그 액수를 뺀다. 
		printf("%s\n%s\namount : %0.6lf\n",name,atemp2->account_name,atemp2->amount); // 이채한 계좌의 주인, 계좌의 번호, 계좌의 액수를 출력한다
		printline();
		printf("%s\n%s\namount : %0.6lf\n",rName,re->account_name,re->amount); // 이채를 받은 계좌의 주인, 계좌의 번호, 계좌의 액수를 출력한다. 
		printline();
		return 0;
	}

}
ACCOUNT* delete(ACCOUNT* accountList, char* accountNum) // 계좌리스트에 accountNum 과 같은 계좌번호를 가진 계좌를 삭제한다 
{
	ACCOUNT * temp;
	for(temp=accountList->account_link;temp!=NULL;temp=temp->account_link)
	{

	if(strcmp(temp->account_name,accountNum)==0)
	{
		//if(temp->amount>0)
		{strcpy(temp->account_name,"NO ACCOUNT MADE"); // accountNum 과 같은 계좌 번호를 가진 계좌를찾고 그 계좌의 계좌 번호를  NO ACCCOUNT MADE 로 바꾸어준다
		temp->amount=0;				// 그 계좌의 액수 또한 0으로 만든다. 
							// NO ACCOUNT MADE로 만들어 주면 나중에 프린트가 될때 제외 되기 때문에 삭제 하는거와 다름 없다.
		break;					// 사실 삭제를 free 해주는 형태로 해주어야 하지만 원인을 찾지 못하는 segmentation error 가 뜨기에
	}	
		//}					// 다른 방법으로 삭제하는 함수를 구현하였다.
	}
	}		
}
void print_History(ACCOUNT* accountList, char* accountNum) // 계좌 내역을 출력하는 함수 
{
	double *dStore;
	int   *nStore;
	ACCOUNT* temp;
	HISTORY* htemp,*temp2;
	int n,i;
	i=0;
	dStore=(double*)malloc(sizeof(double)*100);
	nStore=(int*)malloc(sizeof(double)*100);
	for(temp=accountList->account_link;temp!=NULL;temp=temp->account_link) // 이 루프를 통해 temp 는 accountNum 계좌 번호를 가진 계좌를 가르킨다
	{
		if(strcmp(temp->account_name,accountNum)==0)
		{
			break;
		}
	}
	for(htemp=temp->history;htemp->head!=NULL;htemp->head=htemp->head->next) // 이 루프를 통해 double 배열 dStore과 int 배열 nStore에 history의 내용물을 저장한다
	{	
		*(dStore+i)=htemp->head->current_amount;
		*(nStore+i)=htemp->head->act;
		i++;									// i 는 history stack에 length 를 알려준다 
	}	
	n=0;
	for(htemp=temp->history;htemp->head!=NULL;htemp->head=htemp->head->next) // 배열에 내용을 다시 history 에 저장한다 
	{
		
		htemp->head->act=*(nStore+n);
		htemp->head->current_amount=*(dStore+n);
		n++;
	}

	for(n=0;n<=i;n++)
	{
		switch(*(nStore+n)) // nStore에는 history의 act가 들어가 있엇고 이를 통해 계좌가 어떤 activity 를 했는지 알수있다 
		{
			case 1: printf("%d. [registration] [%s] amount : [%0.6lf] \n", i-n, temp->account_name, *(dStore+n)); // 처음 계좌를 만들었을때 
				break;
			case 2: printf("%d. [deposit and withdrawls] [%s] amount: [%0.6lf] \n",i-n,temp->account_name,*(dStore+n)); // 입금출금해주었을때
				break;
			case 3:	printf("%d. [loan] [%s] amount : [%0.6lf] \n",i-n,temp->account_name,*(dStore+n)); // 대출 해줬을때 
				break;   // 각각 순서, 그 상황, 계좌 번호, 계좌 잔액을 출력한다 
		}
	}
		printline();	
	

}
int select_Menu4(char* cName, int num, BANK* bankList,int *mode) // USER 메뉴를 출력하고 입력을 받는다
{
	BANK* btemp;
	double amount;
	int n;
	char* accountNum, *received;
	accountNum=(char*)malloc(sizeof(char)*100);
	received=(char*)malloc(sizeof(char)*100);
	for(n=0;n<100;n++)
	{
		*(accountNum+n)='\0';
	}
	btemp=bankList;

	if(num==1)   // num 에 따라서 알맞는 은행을 고른다 
	{
		btemp=bankList;   // num이 1,2,3 차례대로  너네,회사,백성 은행을 찾고 btemp 가 그 은행을 가르키게 한다 
	}else if(num==2)
	{
		btemp=bankList->bank_link;
	}else 
		btemp=bankList->bank_link->bank_link;
	
	USER* temp, *userList;
	userList=btemp->users; // userList 는 해당 은행의 고객 리스트이다 
	for(temp=userList->user_link;temp!=NULL;temp=temp->user_link) // 루프를 통해 그 고객 리스트의 해당 이름을 가진 고객을 찾는다. 
	{
		if(strcmp(temp->user_name,cName)==0)  // 이제 temp 는 해당 이름을 가진 고객을 가르킨다. 
		{
			break;
		}
	}
	printf("====  MENU (USER) ======\n");  // 메뉴를 출력한다 
	printf("1. new account registration\n");
	printf("2. deposits and withdrawls \n");
	printf("3. bank transfer \n");
	printf("4. loan\n");
	printf("5. transaction history\n");
	printf("6. account termination\n");
	printf("7. my account list\n");
	printf("8. go to bank menu\n");
	printline();
	printf("select menu : ");
	scanf("%d",&n); 
	while(n<=0||n>8)
	{
		printf("select from (1)~(8): ");   // 사용자가 1에서 8만 입력하게 한다. 그렇지 않다면 다시 입력 받는다 
		scanf("%d",&n);
	}
	switch(n)
	{
		case 1: accountNum=(char*)malloc(sizeof(char)*100);    // new account registration 
			print_account_info(temp->user_name,temp->account);  // 사용자가 계좌를 볼수있게 계좌 리스트에 있는 계좌들을 다 출력한다
			printf("type account number :"); 	// 계좌 번호를 입력 받는다
			scanf("%s", accountNum);
			while(searchAccount(bankList,accountNum)==1)	// 만약 계좌 번호가 사용자의 계좌 리스트에 존재 하지 않는다면
			{
				printf("Account Number already exists\n"); 	// 오류를 출력해주고 다시 계좌번호를 받는다 
				printf("type account number : ");
				scanf("%s",accountNum);
			}
			printline();
			insert_Account(temp,temp->account,accountNum,0); // 새로운 계좌를 계좌 리스트에 넣어준다 
			break;
   		case 2: print_account_info(temp->user_name,temp->account); // deposits and withdrawls 입금출금 구현
			printf("type account number : "); //사용자가 계좌를 볼수있게 사용자의 모든 계좌를 출력한다
			scanf("%s",accountNum);		// 계좌 번호를 입력 받는다 
			while(search_Account_2(temp->account,accountNum)==0) // 계좌 번호가 존재 하지 않는다면 오류를 출력해주고 다시 입력 받는다
			{
				printf("The account does not exists\n");
				printline();
				print_account_info(temp->user_name,temp->account);
				printf("type account number : ");
				scanf("%s",accountNum);
				
			}
			printf("type the amount : "); // 입금,출금할 금액을 입력 받는다
			scanf("%lf",&amount);
			printline();
			if(!update(btemp,temp->account,accountNum,amount)) // 만약 입금,출금이 불가능한 상태이면 모드 6, 즉 USER 메뉴로 다시 돌아가게 한다
			{
				*mode=6;
				break;
			}
			printline();
			print_account_info(temp->user_name,temp->account); // 입금, 출금 후에 계좌를 프린트한다
			break;
		case 3: print_account_info(temp->user_name,temp->account); // bank transfer 계좌 이채를 구현
			printf("type send account number : "); // 보내는 계좌번호를 입력받는다 
			scanf("%s",accountNum);
			while(search_Account_2(temp->account,accountNum)==0)	// 고객이 해당 계좌 번호를 가진 계좌를 가졌는지 확인하고 없다면 다시 입력받는다
			{
				printf("the account number does not exists\n");
				printf("type account number : ");
				scanf("%s",accountNum);
			}
			print_All(bankList);	// 세 은행의 모든 고객의 계좌를 출력한다
			printf("type receive account number : ");
			scanf("%s",received); // 받을 계좌 번호를 입력 받는다 
			while(searchAccount(bankList,received)==0) // 세 은행에서 받을 계좌 번호를 찾고 찾을수 없다면 오류를 입력하고 다시 입력 받는다
			{
				printf("the account number does not exists\n");
				printf("type receive account number : ");
				scanf("%s",received);
			}
			printline();
			if(!transfer(bankList,received,accountNum,temp->account,temp->user_name)) // 계좌 이채가 불가능 하다면 USER MENU 로 돌아간다
			{
				*mode=6;
				break;
			}
			break;
		case 4: printf("%s\nloan limit : %0.6lf\n",btemp->bank_name, btemp->bank_amount+total_bank(btemp)); // loan 대출 구현. 한도를 출력한다 
			printline();						
			print_account_info(temp->user_name,temp->account); // 고객의 계좌 리스트를 출력한다 
			printf("type account number : "); // 계좌번호를 입력 받는다
			scanf("%s",accountNum);
			while(search_Account_2(temp->account,accountNum)==0) // 계좌번호를 가진 계좌를 가지고 있지 않는다면 오류를 출력하고 다시 입력 받는다 
			{
				printf("The account does not exists\n");
				printline();
				print_account_info(temp->user_name,temp->account);
				printf("type account number : ");
				scanf("%s",accountNum);
			}
			if((!loan(btemp,temp->account,accountNum))) // 만약 대출이 불가능한 상태이면 USER MENU 로 돌아간다
			{
				*mode=6;
				break;
			}
			printline();
			print_account_info(temp->user_name,temp->account); // 대출후에 계좌의 상태를 출력
			break;
		case 5: print_account_info(temp->user_name,temp->account); // transaction history  계좌 내역 출력. 
			printf("type account number : ");	// 계좌리스트를 출력하고 계좌번호를 입력 받는다
			scanf("%s",accountNum);
			while(search_Account_2(temp->account,accountNum)==0) // 고객이 해당  계좌번호를 가진 계좌를 가지고 있지 않다면 오류를 출력하고 다시 입력 받는다
			{
				printf("The account does not exists\n");
				printline();
				print_account_info(temp->user_name,temp->account);
				printf("type account number : ");
				scanf("%s",accountNum);
			}
			print_History(temp->account,accountNum); // 계좌 내역을 출력 
			break;
		case 6: print_account_info(temp->user_name,temp->account); // account termination 계좌 삭제를 구현 
			printf("%s\nloan limit : %0.6lf\n",btemp->bank_name, btemp->bank_amount+total_bank(btemp)); // 한도 출력
			printline();
			printf("type account number :");	// 계좌 번호를 입력받는다
			scanf("%s",accountNum);
			if(search_Account_2(temp->account,accountNum)==0) // 고객의 계좌 리스트에 똑같은 계좌번호를 가진계좌가 없다면 오류를 출력하고 USER MENU로 돌아간다
			{
				printf("The account does not exists\n");
				printline();
				*mode=6;
				break;
			}
			if(btemp->bank_amount<=0||temp->account->amount<0) // 은행의 한도가 0일때 계좌 삭제을 금지한다 
			{
				printf("You can not terminate because the bank limit is less than 0\n");
				*mode=6;
				 break;
			}
			else temp->account=delete(temp->account,accountNum);
		case 7: print_account_info(temp->user_name,temp->account); // my accountList 해당 고객의 모든 계좌를 출력 한다
			break;
		case 8: *mode=0;	// 첫번째 화면으로 돌아간다  
			 break;
		
	}
}
void freeBank(BANK* bankList) // 은행 구조체가 사용한  메모리를 삭제해주는 함수
{				// freeBank 를 불러줌으로써 freeUser, freeAccount, freeHistory 함수가 불러진다. 그렇게 모든 은행에 들어가있던 
				// 고객리스트  그리고 그 안에 들어있던 계좌 리스트 그리고 그 안에 들어있던 계좌 내역 스택이 할당 했던 메모리를 다 free해준다 
	BANK* temp;
	for(temp=bankList;temp!=NULL;temp=temp->bank_link) // 계좌에 들어있는 고객 구조체가 사용한 메모리를 삭제한다
	{
		
		freeUser(temp->users);
	}
	
	while(bankList!=NULL) 
	{
		temp=bankList;
		bankList=bankList->bank_link;
		free(temp);
	}
}
void freeUser(USER* userList) // 고객 구조체가 사용한 메모리를 삭제해주는 함수
{
	USER* temp;
	for(temp=userList->user_link;temp!=NULL;temp=temp->user_link) // 고객에 들어있는 계좌 구조체가 사용한 메모리를 삭제한다
	{
		freeAccount(temp->account);
	}
	while(userList!=NULL)
	{
		temp=userList;
		userList=userList->user_link;
		free(temp);
	}
}
void freeAccount(ACCOUNT* accountList) // 계좌 구조체가 사용한 메모리를 삭제해주는 함수
{
	ACCOUNT* temp;
	for(temp=accountList->account_link;temp!=NULL;temp=temp->account_link) // 계좌에 들어가있는 계좌 내역 구조체가 사용한 메모리를 삭제한다 
	{
		freeHistory(temp->history);
	}
	
	while(accountList!=NULL)
	{
		temp=accountList;
		accountList=accountList->account_link;
		free(temp);
	}
}
void freeHistory(HISTORY* history) // 계좌 내역 구조체가 사용한 메모리를 삭제해주는 함수 
{
	NODE* temp;
	
	while(history->head!=NULL)
	{
		temp=history->head;
		history->head=history->head->next;
		free(temp);
	}

}
int main()
{
	FILE * in;
	char* bankName,*personName,*accountNum,*cName;
	double amount,total1,total2,total3;
	total1=0;
	total2=0;
	total3=0;	
	int mode,bankNum,d,k;
	USER* bank1,*bank2,*bank3;
	bank1=(USER*)malloc(sizeof(USER)); // bank 1, bank2, bank3 은 차례대로 너네은행, 회사은행, 백성은행의 고객을 연결한 고객 리스트다. 
	bank2=(USER*)malloc(sizeof(USER));
	bank3=(USER*)malloc(sizeof(USER));
	BANK* bankList;
	bankName=(char*)malloc(sizeof(char)*100); // bankName 은 은행의 이름을 저장하는 char 배열
	personName=(char*)malloc(sizeof(char)*100); // personName 은 고객의 이름을 저장하는 char 배열
	accountNum=(char*)malloc(sizeof(char)*100);	// accountNum 은 계좌의 번호를 저장하는 char 배열
	cName=(char*)malloc(sizeof(char)*100); // cName은 나중에 입력 받을 이름을 저장하는 char 배열 
	mode=0;
	in=fopen("input.txt","r"); // input.txt 이름을 가진 텍스트파일을 연다 
	if(in==NULL)
	{
		printf("input file not found!\n");	// 해당 파일이 없다면 오류를 출력하고 프로그램을 닫는다 
		return 0;
	}
	
	while(fscanf(in,"%s%s%s%lf",bankName,personName,accountNum,&amount)>0) // 파일이 끝날때까지 파일로 부터 은행의이름,고객의이름,계좌의번호를 입력 받는다
	{
		
		if(strcmp(bankName,"너네은행")==0) // bankName이 니네은행이면 bank1 에 해당 USER 를 넣어준다 
		{ 
			total1+=amount;
			insert_User(bank1,personName,accountNum,amount); // bankName이 회사은행이면 bank2에 해당 USER를 넣어준다	
		}else if(strcmp(bankName,"회사은행")==0)
		{	
			total2+=amount; 
			insert_User(bank2,personName,accountNum,amount); 
		
		}else if(strcmp(bankName,"백성은행")==0)
		{
			total3+=amount;
			insert_User(bank3,personName,accountNum,amount); //bankName이 백성은행이면 bank3 에 해당 USER 를 넣어준다
		}
	}

        fclose(in);	
	bankList=Initiate_Bank(bank1,bank2,bank3); // 은행 리스트를 만든다. bank1, bank2, bank3 는 차례대로 니네,회사,백성은행 고객 리스트로 지정해준다. 
	while(1) // 이 루프를 벗어나면 프로그램이 끝난다. 
	{	
		while(mode==0)
		{
			mode=selectMenu_first(bankList); // 초기 메뉴 출력, 입력을 받는다
		}
		if(mode==3)
		{
			break; // 모드가 3일때는 사용자가 Quit 을 선택했을때다 그러므로 while 루프를 벗어나 프로그램을 종료한다  
		}
		while(mode==1) 
		{				// BANK MENU 를 출력하고 입력받는다 
			bankNum=select_Bank(bankList); 
			selected_Bank(bankList,bankNum);
			d=select_Menu2(bankList,bankNum);
			switch(d)
			{
				case 1: mode=4; // select user
					break;
				case 2: mode=5;	// new user registration
					break;
				case 3:	mode=0;  // go to menu 
					break;
			}
		}	
		if(mode==2)
		{
			bankNum=select_Bank(bankList); // bank user and user list 를 출력 해준다
			selected_Bank(bankList,bankNum); // 출력할 bank 를 선택 받는다
			print_User(bankNum,bankList,1);	 // 출력후에 초기 메뉴로 돌아간다. 
			mode=0;	
		}
		while(mode==4) // select user를 선택했을때. 
		{
			print_User(bankNum,bankList,2);
			mode=select_Menu3(bankNum,bankList,1,cName);
			
		}
		while(mode==5) // new user registration 을 선택했을때 
		{
			print_User(bankNum,bankList,2);
			mode=select_Menu3(bankNum,bankList,2,cName);
			
		}
		while(mode==6) // USER MENU 를 출력하고 입력받는다 
		{
			printf("you choose %s\n",cName);
			printline();
			k=select_Menu4(cName,bankNum,bankList,&mode);
		}

	}
	freeBank(bankList); // malloc 을 하여 동적할당해주었던 메모리들을 free해주는 함수를 부른다 
}






