#include <stdio.h>
void fractal(int n, int k, int type);
int powOf3(int);
void printspace(int );
int main (void)
{
	int a,t,b,line;
	
printf("n = ");
scanf("%d",&a);
printf("type =");
scanf("%d",&t);
line=powOf3(a);
	for(b=0;b<line;b++)
	{	
	 fractal(a,b,t);
	printf("\n");
	
	}
return 0;
}
void fractal ( int n, int k, int type)
{
	if(type==1){
     	if(n==0){
 		printf("*");
	 	}
		else if(k<powOf3(n-1)*1)
		{
			 printspace(n);
			 fractal(n-1,k,type);
			 printspace(n);
		 }
	 	else if(k < powOf3(n-1)*2)
		{
			fractal(n-1,k-powOf3(n-1),type);
			fractal(n-1,k-powOf3(n-1),type);
			fractal(n-1,k-powOf3(n-1),type);
		}else
		{
			printspace(n);
			fractal(n-1,k-powOf3(n-1)*2,type);
			printspace,(n);
		}
	}else
	{
    	if(n==0)
		{	
		printf("*");
		}	
        else if (k<powOf3(n-1)*1)
		{
        	fractal(n-1,k,type);
			printspace(n);
			fractal(n-1,k,type);
		}
		else if(k<powOf3(n-1)*2)
		{
           printspace(n);
		   fractal(n-1,k-powOf3(n-1),type);
		   printspace(n);
		}
		else
		{
 			fractal(n-1,k-powOf3(n-1)*2,type);
			printspace(n);
			fractal(n-1,k-powOf3(n-1)*2,type);
		}
   
	}
}   

void printspace(int num)
{
	int i;
	for (i=0; i< powOf3(num-1); i++)
	{
	printf(" ");
	}
	
}

int powOf3(int num)
{
int total=1;
int i;
	for (i=num; i>0; i--)
	{
     total*=3;
	}
return total;
}
